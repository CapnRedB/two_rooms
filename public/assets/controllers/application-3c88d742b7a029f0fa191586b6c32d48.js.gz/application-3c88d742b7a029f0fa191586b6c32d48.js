TwoRooms.ApplicationController = Ember.Controller.extend({
	session: null
});
